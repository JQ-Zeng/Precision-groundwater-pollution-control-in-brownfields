# Weighted Exceedance Rate Autoencoder Model (WER-AM)

This repository contains the source code, dataset, and outputs for identifying key groundwater pollutants using a Weighted Autoencoder Model (WER-AM). This model emphasizes pollutants exceeding regulatory limits by integrating exceedance rates into the autoencoder training process.

## Overview

The WER-AM approach:
- Filters pollutants with non-zero exceedance rates.
- Standardizes and weights concentration data.
- Trains an autoencoder to extract latent features.
- Computes reconstruction error as a measure of feature complexity.
- Combines exceedance rate and reconstruction error to generate a composite importance score for ranking pollutants.

For details on the methodology, please refer to the associated publication and *Supplementary Methods 3*.

## Files

- `wer_am_model.py`: Main script implementing the WER-AM method.
- `Autoencoder_Groundwater pollution data ALL.csv`: Input dataset containing exceedance rates and pollutant concentrations.
- `feature_importance_combined_sorted.csv`: Output file with ranked pollutants (generated after running the model).
- `requirements.txt`: Python dependencies.

## How to Run

1. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the script:
   ```bash
   python wer_am_model.py
   ```

The ranked pollutant importance scores will be saved to `feature_importance_combined_sorted.csv`.

## Citation

If you use this code or data in your research, please cite the corresponding paper (citation details to be added upon acceptance).

## License

This project is shared under an academic use license. Contact the authors for commercial use.
